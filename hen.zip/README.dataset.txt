# chick > Roboflow Instant 3 [Eval]
https://universe.roboflow.com/ramachandran-s-workspace/chick-ppyak

Provided by a Roboflow user
License: CC BY 4.0

