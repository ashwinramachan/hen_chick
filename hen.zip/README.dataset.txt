# hen > 2026-01-18 9:53am
https://universe.roboflow.com/ram-mssmi/hen-zjgzl-hegtm

Provided by a Roboflow user
License: CC BY 4.0

